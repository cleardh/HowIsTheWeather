const mongoose = require('mongoose');
const LocationSchema = mongoose.Schema({
  name: {
    type: String
  },
  address: {
    type: String,
    required: true
  },
  latlng: {
    type: String,
    required: true
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'user'
  },
  username: {
    type: String
  },
  date: {
    type: Date,
    default: Date.now
  }
});

module.exports = Location = mongoose.model('location', LocationSchema);
