const express = require('express');
const config = require('config');
const request = require('request');
const router = express.Router();

// @route   GET api/weather/:latlng
// @desc    Get weater by lat and lng
// @access  public
router.get('/:latlng', (req, res) => {
  try {
    const options = {
      uri: `https://api.darksky.net/forecast/${config.get('darkskyKey')}/${
        req.params.latlng
      }`,
      method: 'GET',
      headers: { 'user-agent': 'node.js' }
    };

    request(options, (error, response, body) => {
      if (error) console.error(error);
      if (response.statusCode !== 200) {
        return res.status(404).json({ msg: 'Weater not found' });
      }
      res.json(JSON.parse(body).currently.summary);
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
});

module.exports = router;
