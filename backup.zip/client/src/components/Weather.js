import React from 'react';
import '../swiper/swiper.min.css';
import '../swiper/swiper.js';

const Weather = () => {
  return (
    <div class='swiper-container'>
      <div class='swiper-wrapper'>
        {/* <!-- Slide 1 --> */}
        <div class='swiper-slide'>
          <div class='card'>
            <div class='sliderText'>
              <h3>Slide 1</h3>
            </div>
            <div class='content'>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae
                cupiditate totam doloremque et nemo aliquam similique. Mollitia
                ipsum magni dolorum culpa unde, quas ea itaque quaerat,
                voluptate autem perferendis est!
              </p>
              <a href='#delete'>
                <i class='far fa-trash-alt fa-2x'></i>
              </a>
            </div>
          </div>
        </div>
        {/* <!-- Slide 2 --> */}
        <div class='swiper-slide'>
          <div class='card'>
            <div class='sliderText'>
              <h3>Slide 2</h3>
            </div>
            <div class='content'>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae
                cupiditate totam doloremque et nemo aliquam similique. Mollitia
                ipsum magni dolorum culpa unde, quas ea itaque quaerat,
                voluptate autem perferendis est!
              </p>
              <a href='#delete'>
                <i class='far fa-trash-alt fa-2x'></i>
              </a>
            </div>
          </div>
        </div>
        {/* <!-- Slide 3 --> */}
        <div class='swiper-slide'>
          <div class='card'>
            <div class='sliderText'>
              <h3>Slide 3</h3>
            </div>
            <div class='content'>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae
                cupiditate totam doloremque et nemo aliquam similique. Mollitia
                ipsum magni dolorum culpa unde, quas ea itaque quaerat,
                voluptate autem perferendis est!
              </p>
              <a href='#delete'>
                <i class='far fa-trash-alt fa-2x'></i>
              </a>
            </div>
          </div>
        </div>
        {/* <!-- Slide Last --> */}
        <div class='swiper-slide'>
          <div class='card'>
            <div class='addSlider'>
              <a href='#'>
                <i class='fas fa-plus'></i>&nbsp;Add
              </a>
            </div>
          </div>
        </div>

        <div class='swiper-slide'>
          <div class='card'>
            <div class='lastSlider'>
              <a href='login.html'>
                <i class='fas fa-sign-out-alt'></i>&nbsp;Sign Out
              </a>
            </div>
          </div>
        </div>
        {/* <!-- Slide End --> */}
      </div>
    </div>
  );
};

export default Weather;
