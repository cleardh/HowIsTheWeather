import React from 'react';

const Signup = () => {
  return (
    <div className='signup'>
      <form className='box'>
        <h1>Sign up</h1>
        <input type='text' name='' placeholder='Username' />
        <input type='password' name='' placeholder='Password' />
        <input type='submit' name='' value='Submit' />
      </form>
    </div>
  );
};

export default Signup;
