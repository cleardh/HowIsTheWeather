import React from 'react';
import { Link } from 'react-router-dom';

const Signin = () => {
  return (
    <div className='signin'>
      <form className='box'>
        <h1>Sign in</h1>
        <input type='text' name='txtUsername' placeholder='Username' />
        <input type='password' name='txtPassword' placeholder='Password' />
        <input type='submit' name='btnLogin' value='Login' />
        <p className='small'>
          <small>
            Click here to&nbsp;
            <Link to='/signup'>sign up</Link>
          </small>
        </p>
      </form>
    </div>
  );
};

export default Signin;
